OrthoFlow 反馈系统 V1.1 修复包

修复内容：
1. 弹窗使用白底深色文字，不再依赖 shadcn 的 bg-background / text-foreground 变量。
2. 原生下拉选项强制使用浅色模式，Windows 浏览器中也能看清。
3. 弹窗提高到 z-[100]，避免和主页内容重叠。
4. “缺少疾病或内容”作为可见反馈类型。
5. 开发环境中，数据库写入失败会显示具体 Supabase 错误代码，便于定位。

替换文件：
components/feedback/FeedbackHub.tsx
app/api/feedback/route.ts
app/api/search-log/route.ts

替换后重启：
Ctrl+C
npm run dev
